(* Wolfram Language Init File *)

Get[ "MathIOmica`MathIOmica`"]